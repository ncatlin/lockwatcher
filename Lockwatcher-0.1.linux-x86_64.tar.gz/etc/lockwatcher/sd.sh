#shell script to execute on emergency shutdown
